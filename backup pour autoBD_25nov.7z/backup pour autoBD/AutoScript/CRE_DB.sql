﻿/* SCRIPT: CRE_DB.sql */

PRINT 'CREATING DATABASE'
/*
:r C:\Users\Utilisateur\Documents\GitHub\Projet_v2\Sprint_3\Glob\BD\CRE_dbProjetE2_20150902.sql
*/

:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\CRE_Package_Jeux_20150902.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\CTE_Package_Jeux_20150910.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\TRG_Package_Jeu_20150915.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\01_INSC_tblSysExp_20150915.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\02_INSC_tblCategorie_15092015.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\03_INSC_tblTheme_20150915.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\04_INSC_tblClassification_20150914.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\05_INSC_tblMode_20150914.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\06_INSC_tblGenre_20150915.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\07_INSC_tblPlateforme_20150915.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\08.2_INSC_tblJeu_20150922.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\09_INSC_tblPlateformeSysExp_15092015.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\10.2_INSC_tblThemeJeu_22092015.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\11.2_INSC_tblVersion_22092015.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\12.2_INSC_tblJeuSemblable_20150922.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_1\13.2_INSC_tblPlateformeJeu_20150922.sql

:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\Employe\CRE_Employe.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\Employe\CTE_Empoye.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\Employe\INSC_tblEmploye.sql

:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\TypeTest\CRE_Type_Test.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\TypeTest\CTE_TypeTest.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\TypeTest\INSC_TypeTest_20151010.sql

:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\CRE_Package_Test.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\CTE_Package_Test.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\INSC_tblProjet_Test.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\INSC_tblCasTest_Test.sql

:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\CRE_Package_Personnel_20151001.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\CTE_Package_Personnel_20151001.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\FCT_Package_Personnel_20151010.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSC_tblDroit_20151108.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSB_tblGroupe.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSB_tblRole.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSC_tblUtilisateur.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSB_tblEmployeTypeTest.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSB_tblGroupeDroit.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSB_tblGroupeUtil.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSC_tblEquipe.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSB_tblEquipeTypeTest.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_2\INSC_tblEquipeTesteur.sql

:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\Recherche\CRE_Recherche.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\Recherche\CTE_Recherche.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\Recherche\INSB_tblFiltre1.sql
:r C:\Users\Utilisateur\Documents\GitHub\BD\Package_3\Recherche\FCT_View_Recherche1.sql

:r C:\Users\Utilisateur\Documents\GitHub\BD\FCT_VUES_AllPackage.sql

PRINT 'DATABASE CREATE IS COMPLETE'
use master;
GO