use dbProjetE2Test;
GO
ALTER TABLE Test.tblTypeTest
ADD CONSTRAINT PK_tblTypeTest_CodeTypeTest	PRIMARY KEY(CodeTypeTest)
PRINT '1- Cr�ation de la contrainte PK_tblTypeTest_CodeTypeTest reussie'
GO

use master;