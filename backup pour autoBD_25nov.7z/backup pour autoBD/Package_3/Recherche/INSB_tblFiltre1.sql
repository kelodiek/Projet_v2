USE dbProjetE2Test;
GO
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('Employe','Employe','VEmployeRecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('Equipe','Equipe','VEquipeRecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('Projet','Projet','VProjetRecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('Version','Version','VVersionRecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('Jeu','Jeu','VJeurecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('Plateforme','Plateforme','VPlateformeRecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('TypeTest','Type Test','VTypeTestRecherche');
INSERT INTO Recherche.tblFiltre1(NomFiltre1,DescFiltre1,NomVue) VALUES ('CasTest','Cas de Test','VCasTest');

GO
USE master;

