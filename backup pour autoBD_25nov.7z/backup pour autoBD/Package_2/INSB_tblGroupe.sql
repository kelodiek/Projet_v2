USE dbProjetE2Test;
GO
INSERT INTO Personnel.tblGroupe(NomGroupe) values('PDG');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Directeur Compte');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Chef Projet');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Chef Equipe');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Agente Bureau');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Modérateur Focus Group');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Testeur');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Client');
INSERT INTO Personnel.tblGroupe(NomGroupe) values('Administrateur');
GO
USE master;