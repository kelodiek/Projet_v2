USE dbProjetE2Test;
GO
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('RP02',3);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('WP02',3);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('RP02',4);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('RP03',4);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('RP01',7);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('WP10',7);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('RP03',7);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('WP01',7);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('RP01',9);
INSERT INTO Personnel.tblGroupeDroit(CodeDroit,IdGroupe) values('Admin',9);
GO
USE master;