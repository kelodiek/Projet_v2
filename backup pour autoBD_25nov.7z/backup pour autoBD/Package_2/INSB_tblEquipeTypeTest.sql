USE dbProjetE2Test;
GO
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(1,'AuCon');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(1,'CoWal');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(2,'AnAct');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(2,'AuCon');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(2,'FoGro');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(2,'PlOuv');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(2,'PlPap');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(3,'DiDoc');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(3,'EnTre');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(4,'AuCon');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(4,'FoGro');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(4,'PrVer');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(5,'AnAct');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(5,'PlOuv');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(5,'PlPap');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(5,'QuEst');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(6,'OcUlo');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'AnAct');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'AnLog');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'AuCon');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'CoWal');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'PlOuv');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'PlSce');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(7,'RePhy');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(8,'DiDoc');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(9,'FoGro');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(9,'OcUlo');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(9,'PlSce');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(10,'AnAct');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(10,'AuCon');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(10,'CoWal');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(10,'RePhy');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(11,'DiDoc');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(11,'EnTre');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(12,'AnHeu');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(12,'PlSce');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(12,'PrVer');
INSERT INTO Personnel.tblEquipeTypeTest(IdEquipe,CodeTypeTest) values(12,'RePhy');

GO
USE master