USE dbProjetE2Prod;
GO
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,)
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
INSERT INTO Personnel.tblEmployeResultatTest(IdEmp,IdResultatTest) values(,);
GO
USE master;