USE dbProjetE2Prod;
GO
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(1,1);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(1,2);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(2,4);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(3,7);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(4,1);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(4,9);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(4,11);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(6,7);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(7,11);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(7,6);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(8,7);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(9,5);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(9,10);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(9,15);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(11,10);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(12,14);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(15,11);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(16,15);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(16,5);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(16,14);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(18,5);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(19,9);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(20,9);
INSERT INTO Personnel.tblEmployeCasTest(IdEmp,IdCasTest) values(20,13);
GO
USE master;

