﻿USE dbProjetE2Test
GO
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('9','10');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('14','11');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('15','12');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('16','13');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('14','15');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('14','16');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('11','12');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('11','13');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('3','4');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('3','5');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('6','7');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('6','8');

INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('18','19');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('18','20');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('21','22');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('21','23');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('24','25');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('24','26');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('27','28');


INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('29','30');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('31','32');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('34','35');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('36','37');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('39','40');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('43','44');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('43','45');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('47','46');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('48','49');
INSERT INTO Jeux.tblJeuSemblable(IdJeuBase,IdJeuSemblable) VALUES ('48','50');


USE master;