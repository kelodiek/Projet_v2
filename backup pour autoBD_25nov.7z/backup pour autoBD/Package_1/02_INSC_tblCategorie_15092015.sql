﻿use dbProjetE2Test;

INSERT INTO Jeux.tblCategorie(CodeCategorie, DescCategorie, ComCategorie) values ('Mobile','T�l�phone intelligent','Samsung Galaxy S6, Galaxy Note 5,Iphone 5, Iphone 6');
INSERT INTO Jeux.tblCategorie(CodeCategorie, DescCategorie, ComCategorie) values ('PCPort','Ordinateur Portable','');
INSERT INTO Jeux.tblCategorie(CodeCategorie, DescCategorie, ComCategorie) values ('PCBur','Ordinateur de Bureau','');
INSERT INTO Jeux.tblCategorie(CodeCategorie, DescCategorie, ComCategorie) values ('Tablet','Tablette intelligente','Tablette Windows,Ipad, Ipad2,Nexus 4, Nexus 5,Galaxy Tab 4, Galaxy Tab 3, Galaxy Tab S, Galaxy Tab A, etc.');
INSERT INTO Jeux.tblCategorie(CodeCategorie, DescCategorie, ComCategorie) values ('ConPort','Console Portative','PS Vita, 3DS');
INSERT INTO Jeux.tblCategorie(CodeCategorie, DescCategorie, ComCategorie) values ('ConSal','Console de salon','PS4, Xbox One, Wii U');

use master;