﻿USE dbProjetE2Test
GO
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('1','52');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('1','64');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('1','1');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('2','31');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('2','3');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('2','20');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('3','31');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('3','56');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('4','79');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('5','79');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('6','78');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('7','78');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('8','78');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('9','80');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('10','43');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('11','79');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('12','73');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('13','81');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('14','72');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('15','74');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('16','75');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('17','76');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('18','82');
INSERT INTO Jeux.tblPlateformeSysExp(IdPlateforme,IdSysExp) VALUES('19','77');
USE master;